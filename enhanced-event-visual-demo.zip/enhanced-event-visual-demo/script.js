const log = (msg) => {
  const li = document.createElement("li");
  li.textContent = msg;
  document.getElementById("log-list").appendChild(li);
};

document.getElementById("clear-log").addEventListener("click", () => {
  document.getElementById("log-list").innerHTML = "";
});

// Capturing phase
document.getElementById("outer").addEventListener("click", () => {
  log("Outer - Capturing");
}, true);

document.getElementById("middle").addEventListener("click", () => {
  log("Middle - Capturing");
}, true);

// Bubbling phase
document.getElementById("outer").addEventListener("click", () => {
  log("Outer - Bubbling");
});

document.getElementById("middle").addEventListener("click", () => {
  log("Middle - Bubbling");
});

// Event Delegation
document.getElementById("middle").addEventListener("click", (e) => {
  if (e.target.classList.contains("inner-btn")) {
    log(`Button ${e.target.dataset.id} Clicked - Delegation`);
  }
});